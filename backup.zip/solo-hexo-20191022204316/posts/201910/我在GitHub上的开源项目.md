title: 我在 GitHub 上的开源项目
date: '2019-10-22 20:08:45'
updated: '2019-10-22 20:31:23'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [CrashReport](https://github.com/Mfk759853063/CrashReport) <kbd title="主要编程语言">Swift</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Mfk759853063/CrashReport/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/CrashReport/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/CrashReport/network/members "分叉数")</span>

记录崩溃前的运行日志



---

### 2. [face_recognition](https://github.com/Mfk759853063/face_recognition) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/face_recognition/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/face_recognition/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/face_recognition/network/members "分叉数")</span>

基于face_recognition库写的一个API



---

### 3. [DataCache](https://github.com/Mfk759853063/DataCache) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/DataCache/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/DataCache/stargazers "收藏数")&nbsp;&nbsp;[🖖`3`](https://github.com/Mfk759853063/DataCache/network/members "分叉数")</span>

[[KNCache shareCache] saveData:data forKey:stringValue];



---

### 4. [Socket-Packet](https://github.com/Mfk759853063/Socket-Packet) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/Socket-Packet/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/Socket-Packet/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/Socket-Packet/network/members "分叉数")</span>

服务端封包，客户端拼包



---

### 5. [KNInputView](https://github.com/Mfk759853063/KNInputView) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/KNInputView/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/KNInputView/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/KNInputView/network/members "分叉数")</span>

Chat Input View Support Emoji Keybaord



---

### 6. [KNToggleView](https://github.com/Mfk759853063/KNToggleView) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/KNToggleView/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/KNToggleView/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/KNToggleView/network/members "分叉数")</span>

一个展开、收起控件



---

### 7. [XHHelper](https://github.com/Mfk759853063/XHHelper) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/XHHelper/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/XHHelper/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/XHHelper/network/members "分叉数")</span>





---

### 8. [SwiftStudy](https://github.com/Mfk759853063/SwiftStudy) <kbd title="主要编程语言">Swift</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/SwiftStudy/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/SwiftStudy/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/SwiftStudy/network/members "分叉数")</span>

学习Swift



---

### 9. [CopyLabel](https://github.com/Mfk759853063/CopyLabel) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/CopyLabel/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Mfk759853063/CopyLabel/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/CopyLabel/network/members "分叉数")</span>

This is a long press label to pop-po menu , only copy text .



---

### 10. [sign-api](https://github.com/Mfk759853063/sign-api) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Mfk759853063/sign-api/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Mfk759853063/sign-api/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Mfk759853063/sign-api/network/members "分叉数")</span>

签到系统

