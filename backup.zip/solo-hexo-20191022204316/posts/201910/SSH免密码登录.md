title: SSH 免密码登录
date: '2019-10-22 20:04:55'
updated: '2019-10-22 20:04:55'
tags: [免密, ssh]
permalink: /articles/2019/10/22/1571745895409.html
---

# 情况1

## 本机已有 `id_rsa.pub`文件（之前配置过ssh免密登录）
### 将本地的id_rsa.pub文件复制到服务器 

```
    scp ~/.ssh/id_rsa.pub root@x.x.x.x:
```

### 然后登录服务器将id_rsa.pub里面的公钥复制服务器的.ssh/authorized_keys文件内

```
echo id_rsa.pub >> ~/.ssh/authorized_keys
```

### 登录服务器 ssh root@x.x.x.x没问题的话就不需要登录密码了

# 情况2

## 本机没有 id_rsa.pub文件（之前未配置过ssh免密登录）
### 生成公私钥,有提示请直接enter

```
ssh-keygen –t rsa –P ''
```

### 然后重复情况一

## Done


# 疑难杂症


### 重启ssh服务

```
service sshd restart
```

```
当把本机的id_rsa.pub写入到服务器的authorized_keys文件时，远程登录还需要密码的话，参考文件权限及所有者
<strong>ls -ll</strong>
服务器再开一个远程登录的商品，查看认证过程
 /usr/sbin/sshd -d -p 2222 
本机ssh 到服务器的2222端口，如果提示 
Authentication refused: bad ownership or modes for directory /root
那应该是根目录的用户不对,使用
chown root:root .
尝试登录
```

```
