title: CentOS 安装 docker及docker-compose
date: '2019-10-22 20:00:08'
updated: '2019-10-22 20:32:17'
tags: [docker, docker-compose]
permalink: /articles/2019/10/22/1571745608204.html
---
# 安装步骤

- 安装docker

  - 升级yum安装包，确保都是最新的版本

 ```
  sudo yum update -y

  ```
  - 在yum repository增加docker的repository(没有的话新建一个)

 ```
  sudo vim /etc/yum.repos.d/docker.repo

  ```
 输入以下内容并保存：

 ```
  [dockerrepo]

  name=Docker Repository

  baseurl=https://yum.dockerproject.org/repo/main/centos/$releasever/

  enabled=1

  gpgcheck=1

  gpgkey=https://yum.dockerproject.org/gpg

  ```
  - 安装docker-engine

 ``` 
  sudo yum install docker-engine

  ```
  - 安装docker-engine完成后，启动docker服务

 ```
  sudo systemctl start docker.service
  ```
- 安装docker-compose

  - 安装企业版linux附加包（epel)

 ```
  yum -y install epel-release

  ```
  - 安装pip(如果安装了跳过)

 ```
  yum -y install python-pip

  ```
  - 安装docker-compose

 ```
  pip install docker-compose

  pip install -i https://pypi.tuna.tsinghua.edu.cn/simple docker-compose //国内加速

  ```
- docker 国内加速

  - 编辑```/etc/docker/daemon.json```（没有就新建文件）写入：

 ```
  {
  "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn"]
  }

  ```
  - 重启docker服务
 ```

  sudo systemctl stop docker.service

  sudo systemctl start docker.service

  ```
