title: Vue 学习笔记(一)
date: '2019-10-22 20:05:31'
updated: '2019-10-23 15:22:50'
tags: [vue, code]
permalink: /articles/2019/10/22/1571745930907.html
---
![](https://img.hacpai.com/bing/20171114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 有关Vue中父组件通过prop传值给子组件时，是否加v-bind的问题

只有传递<font color=red>字符串常量时</font>，不采用v-bind形式，其余情况均采用v-bind形式传递
传入的值title为一个常量(静态prop)时，不加v-bind(或者：)
```js
<blog-post title="My journey with Vue"></blog-post>
```
传入的值title为一个变量(动态prop)时，加v-bind(或者：)
```js
<blog-post v-bind:title="titleValue"></blog-post>
```
总结:根据以上说明，可以看出只有当字符串以静态/常量形式传递时，才不需要也不能用v-bind传递


### 如何理解Vue.js的组件中的slot?

slot的意思是插槽，想想你的电脑主板上的各种插槽，有插CPU的，有插显卡的，有插内存的，有插硬盘的，所以假设有个组件是computer，其模板是
<template><div><slotname="CPU">这儿插你的CPU</slot><slotname="GPU">这儿插你的显卡</slot><slotname="Memory">这儿插你的内存</slot><slotname="Hard-drive">这儿插你的硬盘</slot></div></template>
那么你要攒一个牛逼轰轰的电脑，就可以这么写：

```js
<template>
  <computer>
    <div slot="CPU">Intel Core i7</div>
    <div slot="GPU">GTX980Ti</div><divslot="Memory">Kingston 32G</div>
    <div slot="Hard-drive">Samsung SSD 1T</divt>
  </computer>
</template>
```

```
