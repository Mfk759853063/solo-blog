title: 定时备份Docker版Mysql数据库
date: '2019-11-15 14:17:38'
updated: '2019-11-15 14:41:53'
tags: [docker, docker-compose, mysql, 备份]
permalink: /articles/2019/11/15/1573798658567.html
---
## 记录如下：
#### 1.将宿主机的备份文件映射到容器内，我这里是/volume2/disk2/backup 映射到容器内的/backup文件夹
#### 2.查看本机安装的Docker Mysql容器：
![image.png](https://img.hacpai.com/file/2019/11/image-828b81c2.png)
#### 3.执行具体的备份命令
```
docker exec 容器名 bash ./backup/xxx/mysqlBackup.sh
```
#### 备份完成！

#### 使用Cron每日定时备份（每日3点执行）
```
0 0 3 * * ? docker exec 容器名 bash ./backup/xxx/mysqlBackup.sh
```
##### 以上就完成了日常数据库数据备份

##### 另外还可以使用<font color=Red>主从同步</font>的方式备份数据库（热备份），我这里需求没这么多，所以就不介绍了，有兴趣的自行尝试哈。

##### 同理，使用docker安装的各种服务，宿主也可用``` docker exec ```此种方式来访问容器提供的服务

