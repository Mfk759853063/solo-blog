title: 解决 Application Loader 一直卡在 “正在通过 App Store 进行鉴定”
date: '2019-10-26 11:39:21'
updated: '2019-10-26 12:32:36'
tags: [iOS]
permalink: /articles/2019/10/26/1572061161667.html
---
#### 卡在 **正在通过 App Store 进行鉴定** 解决方案：

1.进入到个人目录
 ```
cd ~
```
2.将之前的iTMSTransporter 备份（Xcode 在线上传和Application Loader 都是通过iTMSTransporter来操作的）

```
mv .itmstransporter/ .old_itmstransporter/
```
3. 然后重新更新iTMSTransporter

```
"/Applications/Xcode.app/Contents/Applications/Application Loader.app/Contents/itms/bin/iTMSTransporter"
```
如图：
![image.png](https://img.hacpai.com/file/2019/10/image-5538fcd5.png)


等待更新结束后，重新使用Application Loader 进行上传， 不出意外的话就是上传成功！

如图：
![image.png](https://img.hacpai.com/file/2019/10/image-cdc8c209.png)

