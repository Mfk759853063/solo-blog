title: 打开Mac OSX原生的读写NTFS功能
date: '2019-10-22 20:04:26'
updated: '2019-10-23 15:23:13'
tags: [ntfs, mac]
permalink: /articles/2019/10/22/1571745866025.html
---
![](https://img.hacpai.com/bing/20190504.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


## 1. 插上磁盘
此时Mac桌面应该会显示出插入的磁盘，但是当你想把文件拖入磁盘的时候，发现是不能拖进去的，这时候查看磁盘的属性应该是Windows NTFS格式的。

## 2. 打开终端
查看磁盘的Volume Name

`diskutil list`

在终端键入如上命令可以看到你的磁盘的Volume Name，如我的Volume Name就是```本地磁盘```

![diskutil list](http://pis410flm.bkt.clouddn.com/disktuol.png)

## 更新 /etc/fstab文件

```sudo nano /etc/fstab```

输入密码，然后输入```LABEL=本地磁盘 none ntfs rw,auto,nobrowse```，其中```本地磁盘```就是你的磁盘名字。

完成这里以后按 Ctrl + X，这时候会出现要不要保存的字样，请按 Y 然后回车退出当前页面，然后重启电脑

## 显示磁盘在finder

当电脑重启完以后你会发现磁盘在你finder和桌面上都不显示了。因为这个```本地磁盘```分区是挂/Volumes下的，我们把这个目录在桌面做一个快捷方式就行了。

```sudo ln -s /Volumes/本地磁盘 ~/Desktop/本地磁盘```

然后我们就可以再桌面上看到插入的磁盘了。

## 最后这时候就可以把文件拷贝到磁盘中去了。至此，打开系统原生的ntfs功能完成，妈妈再也不用担心我的硬盘。

> 教程来自于： https://juejin.im/entry/59546970f265da6c34332bdd
```
