title: CentOS 7 重装Mysql5.7.25 笔记
date: '2019-10-22 20:02:45'
updated: '2019-10-22 20:02:45'
tags: [Mysql, 安装]
permalink: /articles/2019/10/22/1571745765812.html
---

# 卸载方法(yum 方式)

### 查看yum是否安装过mysql

``` yum list installed mysql* ```


![pic1](http://pnb34w3ti.bkt.clouddn.com/1112615-bba6b2eec0c79a1f.png)


### 如显示了列表，说明系统中有MySQL 

### yum 卸载 

### 根据列表上的名字

``` yum remove mysql-community-client mysql-community-common mysql-community-libs mysql-community-libs-compat mysql-community-server mysql57-community-release  ```


``` rm -rf /var/lib/mysql ```


``` rm /etc/my.cnf ```

### rpm查看安装

``` rpm -qa | grep -i mysql ```

![pic2](http://pnb34w3ti.bkt.clouddn.com/2.png)

### rpm 卸载

<pre>
<code>
rpm -e mysql57-community-release-el7-9.noarch 

rpm -e mysql-community-server-5.7.17-1.el7.x86_64  

rpm -e mysql-community-libs-5.7.17-1.el7.x86_64  

rpm -e mysql-community-libs-compat-5.7.17-1.el7.x86_64  

rpm -e mysql-community-common-5.7.17-1.el7.x86_64  

rpm -e mysql-community-client-5.7.17-1.el7.x86_64 

cd /var/lib/ 

rm -rf mysql/  
</code>
</pre>


### 清除余项

``` whereis mysql ```

eg: mysql: /usr/bin/mysql /usr/lib64/mysql /usr/local/mysql /usr/share/mysql /usr/share/man/man1/mysql.1.gz

#### 删除上面的文件夹
rm -rf /usr/bin/mysql

### 删除配置

``` rm –rf /usr/my.cnf ```

``` rm -rf /root/.mysql_sercret ```

### 剩余配置检查

``` chkconfig --list | grep -i mysql ```

``` chkconfig --del mysqld ```

#### 根据上面的列表，删除 ,如：mysqld

# 安装（Yum）

#### yum安装，先要搞到源

<pre>
<code>
wget http://repo.mysql.com/mysql57-community-release-el7-9.noarch.rpm 

sudo rpm -ivh mysql57-community-release-el7-9.noarch.rpm 
</code>
</pre>



#### 安装mysql

``` yum install mysql mysql-server ```


#### 如果中途关机，或者下载挂了，请执行卸载步骤后，再来一次。

#### 完成后记住要给root上密码

#### mysql5.7.x版本有一些新的变化，大致是 

#### 1.mysqld_safe已经被废弃，rpm安装包默认不会安装mysqld_safe

#### 2.user表中password列已经更改为authentication_string

<pre>
<code>
sudo systemctl stop mysqld.service 

sudo systemctl set-environment MYSQLD_OPTS="--user=mysql --skip-grant-tables --skip-networking" 

sudo systemctl start mysqld.service 

mysql -u root mysql 

mysql > UPDATE mysql.user SET authentication_string=PASSWORD("abcdef")  WHERE user='root' and host='localhost;

mysql > flush privileges; 

mysql > quit 

sudo systemctl unset-environment MYSQLD_OPTS 

sudo systemctl restart mysqld.service 
</code>
</pre>



##### 经过以上几个步骤操作之后，重新使用root登录成功


#### 启动与开放远程访问

<pre>
<code>
systemctl start mysqld
mysql -u root -p
+ 授权远程访问
use mysql;
grant all privileges  on *.* to root@'%' identified by "root";
flush privileges;
</code>
</pre>


## 常见问题：

<pre>ERROR 1819 (HY000): Your password does not satisfy the current policy requirements

该问题其实与mysql的validate_password_policy的值有关。查看一下msyql密码相关的几个全局参数：

<code>
mysql> select @@validate_password_policy;
+----------------------------+
| @@validate_password_policy |
+----------------------------+
| MEDIUM                     |
+----------------------------+
1 row in set (0.00 sec)
 
 
mysql> SHOW VARIABLES LIKE 'validate_password%';
+--------------------------------------+--------+
| Variable_name                        | Value  |
+--------------------------------------+--------+
| validate_password_dictionary_file    |        |
| validate_password_length             | 8      |
| validate_password_mixed_case_count   | 1      |
| validate_password_number_count       | 1      |
| validate_password_policy             | MEDIUM |
| validate_password_special_char_count | 1      |
+--------------------------------------+--------+
6 rows in set (0.08 sec)
</code>

#### 修改mysql参数配置

<code>
mysql> set global validate_password_policy=0;
Query OK, 0 rows affected (0.05 sec)
 
mysql> 
mysql> 
mysql> set global validate_password_mixed_case_count=0;
Query OK, 0 rows affected (0.00 sec)
 
mysql> set global validate_password_number_count=3;
Query OK, 0 rows affected (0.00 sec)
 
mysql> set global validate_password_special_char_count=0;
Query OK, 0 rows affected (0.00 sec)
 
mysql> set global validate_password_length=3;
Query OK, 0 rows affected (0.00 sec)
 
mysql> SHOW VARIABLES LIKE 'validate_password%';
+--------------------------------------+-------+
| Variable_name                        | Value |
+--------------------------------------+-------+
| validate_password_dictionary_file    |       |
| validate_password_length             | 3     |
| validate_password_mixed_case_count   | 0     |
| validate_password_number_count       | 3     |
| validate_password_policy             | LOW   |
| validate_password_special_char_count | 0     |
+--------------------------------------+-------+
6 rows in set (0.00 sec)
</code>

#### 修改简单密码：

<code>
mysql> SET PASSWORD FOR 'root'@'localhost' = PASSWORD('123');
Query OK, 0 rows affected, 1 warning (0.00 sec)
</code>

#### Done
</pre>
```
