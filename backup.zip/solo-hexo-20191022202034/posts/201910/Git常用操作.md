title: Git 常用操作
date: '2019-10-22 20:01:19'
updated: '2019-10-22 20:01:19'
tags: [git]
permalink: /articles/2019/10/22/1571745678988.html
---

## 一 .gitignore 更新了，需要删除仓库track记录

```git rm -r --cached <file>```

然后再 ```git add . ```

最后 ```git commit ```


## 二 fatal: refusing to merge unrelated histories

解决:

```--allow-unrelated-histories```


## 三 恢复到本地仓库的某一版本

```git reset --hard <commit号>```

## 四 git push时有些不存在了的文件还会被尝试提交
>>> remote: warning: File static/a.bin is 95.37 MB; this is larger than Git@OSC's recommended maximum file size of 50 MB remote: error: File static/a.bin is 442.09 MB; this exceeds Git@OSC's file size limit of 100 MB remote: error: hook declined to update refs/heads/master


解决:
``` git filter-branch --index-filter 'git rm -r --cached --ignore-unmatch xxx' HEAD ```
```
